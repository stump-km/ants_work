# Implementation status — FCF v0.1

## Included
- Rust 2024 workspace, no external dependencies.
- Domain IDs, revisions, work-item lifecycle, commitment ownership, evidence assessment lifecycle.
- Application service for agent registration, work publication, exclusive claiming, evidence submission and independent assessment.
- Shared board projection and ordered in-memory event log.
- Executable three-agent scenario.
- Unit tests for stale revisions, exclusive claim, self-verification rejection, contested evidence and unauthorized writes.
- Windows PowerShell and Unix verification scripts.
- Architecture/protocol baseline included under `docs/`.

## Not included
- HTTP/API server, database, cryptographic authentication, durable event outbox, distributed concurrency, real notification delivery, external agent adapters, UI.

## Verification status in generation environment
Rust/Cargo are not installed in the generation environment. Therefore compilation, tests, formatting and Clippy have not been executed here. Run `scripts/verify.ps1` on Windows PowerShell or `scripts/verify.sh` on Linux/macOS with Rust 1.85+. Do not treat source generation as a passing build.

## Known prototype constraints
- Project revision is a coarse optimistic-concurrency fence for this single-process prototype.
- Event sequence is process-local and resets on restart.
- The board is a projection assembled from in-memory collections.
- Authentication is represented only by registered Agent IDs; there is no cryptographic identity proof.
- Evidence status transitions are domain state changes; detailed source artifacts and verification provenance remain a future protocol implementation task.
- In-memory methods are atomic only within one process; they do not prove distributed concurrency correctness.
