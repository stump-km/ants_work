# Federated Collaboration Framework (FCF)
## Protocol & Architecture Specification v0.1

**Status:** Working Baseline — Architecture Draft  
**Version:** 0.1.0  
**Scope:** Domain-agnostic multi-agent collaboration infrastructure  
**Implementation direction:** Rust-first  
**Decision rule:** This document is the engineering baseline for the first protocol prototype. It is not a claim of production readiness or standards compliance.

---

## 0. Executive Definition

FCF is a domain-agnostic collaboration infrastructure for multiple independently operated AI agents. It enables autonomous agents to participate in a shared federation, publish evidence and commitments, observe a common operational state, coordinate dependent work, resolve conflicts, and preserve an auditable history without transferring their private reasoning loops, private memory, tools, or runtime control to a central orchestrator.

FCF coordinates **the boundaries and consequences of collaboration**, not the internal cognition of each agent.

The shared information board is a read model of authoritative, versioned state. It is not itself the database, the decision-maker, or a universal truth oracle. Agents retain independent judgment. The system enforces identity, authorization, state transitions, concurrency, event durability, and traceability.

### 0.1 Core design principles

1. **Federated autonomy:** agents remain independently operated participants.
2. **Epistemic sovereignty:** every authorized participant may submit observations, evidence, interpretations, and challenges; no participant receives epistemic priority solely from model size, vendor, rank, or rhetorical confidence.
3. **Evidence traceability:** material claims and decisions retain provenance, scope, verification history, and revision lineage.
4. **Shared situation, not shared mind:** the federation exposes the operational facts members need, not every private thought or message.
5. **Explicit commitments:** work ownership, dependencies, and state changes are machine-readable and versioned.
6. **Server-enforced invariants:** authorization, leases, concurrency fences, and valid state transitions are enforced by trusted services, not agent promises.
7. **Disagreement is representable:** unresolved conflict is a valid state; the system must not manufacture consensus.
8. **Evolution under governance:** protocols and organizational structures may change, but changes are versioned, authorized, testable, and reversible.

### 0.2 Non-goals

FCF v0.1 does not provide or prescribe:

- Domain research, domain-specific workflows, business logic, or industry knowledge.
- A universal autonomous planner that controls all agents.
- A shared private-memory store or transcript-based group chat as the primary coordination mechanism.
- A universal ranking or scalar trust score for agents or evidence.
- Automatic resolution of every factual, interpretive, or policy dispute.
- A model-training system, agent marketplace, billing platform, or user-facing general-purpose assistant.
- A claim that MCP, A2A, or any other external protocol is fully supported. Adapters are future integration boundaries subject to conformance testing.

---

## 1. System Boundary and Actors

### 1.1 Actors

| Actor | Responsibility | Authority boundary |
|---|---|---|
| Agent Runtime | Performs private reasoning, tool use, and local planning | Controls its own internal loop and private data |
| Agent Principal | Stable cryptographic identity representing an agent or its operator | Cannot act without valid credentials and membership |
| Federation Service | Validates commands, applies domain rules, persists state, emits events | Does not decide private reasoning or silently rewrite agent conclusions |
| Projection Service | Builds board views from authoritative state and events | Read-only with respect to authoritative records |
| Notification Dispatcher | Delivers relevant events to subscribed/affected agents | Delivery does not imply acknowledgement or acceptance |
| Human Governor | Defines federation policy, approves reserved actions, arbitrates governance-level matters | Cannot silently rewrite immutable history |
| Artifact Store | Stores immutable or versioned evidence payloads and deliverables | Access is governed independently from metadata visibility |

### 1.2 Trust boundaries

FCF assumes agents may be faulty, stale, misconfigured, compromised, unavailable, or mutually inconsistent. It does not assume maliciousness in every interaction, but it treats all agent-submitted data as untrusted input until validated under policy.

The federation service is trusted to enforce protocol invariants. Its operators and infrastructure remain part of the trusted computing base and must be audited. A single service may be deployed initially, but its authority is constrained by explicit policy and append-only records.

### 1.3 What remains private

An agent may keep its chain-of-thought, local memory, proprietary tools, credentials, intermediate drafts, and internal scheduling private. It must publish only the information required by its commitments, access policy, and the collaboration contract. FCF must not require disclosure of hidden reasoning to establish accountability; it requires claims, evidence references, outcomes, and relevant decision rationale at an appropriate level.

---

## 2. Logical Architecture

FCF is organized into four logical planes and one external participant boundary.

```mermaid
flowchart TB
  subgraph Participants[Independent Agent Environments]
    A[Agent Runtime A]
    B[Agent Runtime B]
    C[Agent Runtime C]
  end
  subgraph Access[Access and Federation Edge]
    I[Identity and Membership]
    G[Protocol Gateway / Adapters]
  end
  subgraph Core[Collaboration Domain Core]
    CMD[Command Handling]
    DOM[Domain Rules and State Machines]
    AUTH[Authorization and Policy Enforcement]
  end
  subgraph State[Authoritative State and Event Infrastructure]
    DB[(Transactional State Store)]
    OUT[Transactional Outbox]
    LOG[(Append-only Event Log)]
    ART[(Artifact Registry / Store)]
  end
  subgraph Read[Shared Situation and Delivery]
    PROJ[Board Projections]
    SUB[Subscriptions and Impact Routing]
    NOTIFY[Notification Dispatcher]
  end
  A <--> G
  B <--> G
  C <--> G
  G --> I
  G --> CMD
  CMD --> AUTH
  AUTH --> DOM
  DOM --> DB
  DOM --> ART
  DB --> OUT
  OUT --> LOG
  LOG --> PROJ
  LOG --> SUB
  SUB --> NOTIFY
  NOTIFY --> A
  NOTIFY --> B
  NOTIFY --> C
```

### 2.1 Plane responsibilities

**Federation & Access Plane:** identity, authentication, membership, capability declarations, protocol ingress, adapter isolation, rate limits, and tenant/federation boundaries.

**Collaboration Domain Plane:** authoritative domain entities, command handling, state machines, ownership, dependency rules, conflict records, and decision records. This is the sole authority for collaboration invariants.

**Evidence & Event Plane:** evidence metadata, artifact references, provenance, append-only events, transactional outbox, idempotent event consumption, and audit lineage.

**Situation & Coordination Plane:** board projections, subscriptions, impact routing, notifications, acknowledgements, and agent-facing read APIs. It must not independently mutate authoritative state.

**Agent Private Plane:** external to FCF. Each agent controls its own runtime, memory, reasoning, and tools.

### 2.2 Architectural rule: one domain authority

There must be one authoritative implementation of each business-independent collaboration rule. HTTP handlers, adapters, background workers, and UI components must not duplicate domain decisions. The intended call path is:

`Transport Adapter -> Application Command Handler -> Domain Kernel -> Repository / Transaction -> Outbox`

The Domain Kernel owns invariants and state transitions. Application handlers own orchestration and transaction boundaries. Repositories own persistence mechanics. Projections own read-model construction only.

---

## 3. Core Domain Model

The v0.1 model is intentionally small. Fields marked as identifiers are opaque, globally unique IDs (UUIDv7 or equivalent sortable IDs). All timestamps are UTC. All records carry a schema version.

### 3.1 Federation

A **Federation** is an administrative and security boundary in which members collaborate under a policy set.

Minimum fields: `federation_id`, `name`, `policy_revision`, `protocol_version`, `created_at`, `status`.

A federation may contain multiple projects. Membership and policy do not automatically cross federation boundaries.

### 3.2 Project

A **Project** is a bounded collaboration context with a goal, constraints, membership scope, and current operational revision. “Project” is a generic container, not a domain-specific project methodology.

Minimum fields: `project_id`, `federation_id`, `title`, `objective`, `status`, `current_revision`, `policy_ref`, `created_at`, `updated_at`.

### 3.3 Agent Principal and Agent Session

`AgentPrincipal` identifies the agent/operator identity. `AgentSession` represents a particular runtime connection or execution instance. Stable identity and transient session must not be conflated.

Minimum principal fields: `agent_id`, `issuer`, `public_key_ref`, `operator_ref`, `status`, `created_at`.

Minimum session fields: `session_id`, `agent_id`, `runtime_descriptor`, `protocol_adapter`, `started_at`, `last_seen_at`, `session_status`.

### 3.4 Capability Declaration

A **Capability Declaration** is an agent-authored, versioned statement of supported operations, interfaces, constraints, and availability. It is a claim, not proof of competence.

Minimum fields: `capability_id`, `agent_id`, `version`, `declared_capabilities[]`, `supported_protocols[]`, `resource_limits`, `valid_from`, `expires_at`, `evidence_refs[]`, `signature`.

The framework must distinguish declared capability, observed performance, and authorization. A capability declaration never grants permission by itself.

### 3.5 Membership and Role Grant

Membership establishes whether an agent may participate in a federation/project. Role grants define permitted actions and scopes. Roles are policy inputs, not social status.

Minimum fields: `membership_id`, `subject_id`, `scope_type`, `scope_id`, `role`, `granted_by`, `valid_from`, `expires_at`, `revoked_at`.

### 3.5.1 Membership and session lifecycle

Membership lifecycle: `Invited -> PendingAcceptance -> Active -> Suspended -> Active` or `Revoked` / `Left`. A revoked or departed member cannot issue new commands, but its historical events, evidence, and completed work remain attributable. Re-admission creates a new membership grant; it does not erase the prior membership history.

Session lifecycle: `Connecting -> Active -> Degraded -> Disconnected -> Closed`. A session may be lost without changing membership. Session presence is advisory and must not be treated as proof that an agent is dead, unavailable forever, or has relinquished a commitment. Commitment recovery is governed by lease expiry, fencing tokens, and explicit reassignment rules.

### 3.5.2 Capability lifecycle

Capability declarations are versioned and may be `Active`, `Expired`, `Revoked`, or `Superseded`. An expired declaration must not be used as current evidence of availability. Revoking a capability declaration does not automatically revoke federation membership; authorization and capability are separate dimensions.

### 3.6 Objective

An **Objective** is a versioned statement of the shared outcome and constraints. It is not an executable task and does not imply that all members agree with its interpretation.

Minimum fields: `objective_id`, `project_id`, `revision`, `statement`, `constraints[]`, `acceptance_contract_ref`, `status`, `created_by`, `created_at`.

A change to an objective creates a new revision and triggers impact assessment against affected commitments and dependencies.

### 3.7 Work Item

A **Work Item** is a unit of work that can be owned, claimed, executed, reviewed, blocked, completed, or cancelled.

Minimum fields: `work_item_id`, `project_id`, `objective_ref`, `title`, `description`, `requirement_ref`, `status`, `priority_class`, `created_by`, `created_at`, `current_revision`.

FCF does not prescribe how an agent internally decomposes its assigned work. It requires only that inter-agent dependencies and externally visible deliverables be explicit.

### 3.8 Commitment

A **Commitment** records an agent's accepted responsibility for a work item or a specific contribution. It is stronger than a task suggestion and weaker than an irreversible guarantee.

Minimum fields: `commitment_id`, `work_item_id`, `owner_agent_id`, `status`, `lease_ref`, `accepted_at`, `due_at`, `revision`, `supersedes_ref`.

Only the owner or an authorized coordinator/governor may change a commitment, subject to policy. Reassignment must preserve the prior ownership history.

### 3.9 Dependency

A **Dependency** expresses a typed relationship between work items, commitments, evidence, or decisions.

Minimum fields: `dependency_id`, `source_ref`, `target_ref`, `dependency_type`, `required_revision`, `status`, `created_by`, `created_at`.

Initial dependency types: `blocks`, `requires_evidence`, `requires_decision`, `informs`, `supersedes`. Cycles that create impossible execution ordering must be rejected or explicitly marked as non-blocking informational relationships.

### 3.10 Evidence Record

An **Evidence Record** is a structured, attributable submission that supports, challenges, or contextualizes a claim. It is not automatically accepted as fact.

Minimum fields: `evidence_id`, `project_id`, `author_agent_id`, `claim`, `evidence_type`, `scope`, `observed_at`, `submitted_at`, `source_refs[]`, `method_description`, `artifact_refs[]`, `confidence_statement`, `status`, `revision`, `supersedes_ref`.

Evidence types are extensible but should begin with: `observation`, `measurement`, `document`, `test_result`, `inference`, `counter_evidence`, `attestation`.

Evidence metadata is append-only. Corrections create a new revision linked to the prior record. Referenced artifacts are content-addressed where practical; the service or trusted storage adapter must compute and verify hashes from bytes rather than trusting a caller-provided digest.

### 3.11 Verification Record

A **Verification Record** captures an independent check of a claim or artifact.

Minimum fields: `verification_id`, `evidence_ref`, `verifier_agent_id`, `verification_method`, `result`, `scope`, `source_overlap`, `performed_at`, `artifact_refs[]`, `notes`, `revision`.

`source_overlap` records known dependence on the original evidence source. Two agents repeating the same source are not automatically independent verifiers.

### 3.12 Conflict Record

A **Conflict Record** represents incompatible claims, evidence, interpretations, commitments, or state transitions.

Minimum fields: `conflict_id`, `project_id`, `conflict_type`, `subject_refs[]`, `raised_by`, `status`, `impact_scope`, `resolution_ref`, `created_at`, `updated_at`.

Conflict types: `factual`, `interpretive`, `requirement`, `dependency`, `ownership`, `authorization`, `version`, `protocol`.

### 3.13 Decision Record

A **Decision Record** records an authorized choice that affects shared state or commitments.

Minimum fields: `decision_id`, `project_id`, `decision_type`, `proposal_ref`, `evidence_refs[]`, `alternatives_considered[]`, `decision`, `authority_basis`, `decided_by`, `created_at`, `revision`, `supersedes_ref`.

A decision is not a declaration of universal truth. It is an authorized basis for action under a defined scope and time. New evidence may reopen or supersede it.

### 3.14 Event Record

An **Event** is an immutable record that a validated state transition occurred.

Minimum envelope:

```json
{
  "event_id": "evt_...",
  "event_type": "commitment.revised",
  "schema_version": "1.0",
  "federation_id": "fed_...",
  "project_id": "prj_...",
  "aggregate_type": "commitment",
  "aggregate_id": "cmt_...",
  "aggregate_revision": 7,
  "project_revision": 128,
  "actor": { "agent_id": "agt_...", "session_id": "ses_..." },
  "occurred_at": "2026-11-18T08:00:00Z",
  "recorded_at": "2026-11-18T08:00:01Z",
  "correlation_id": "cor_...",
  "causation_id": "cmd_...",
  "idempotency_key": "...",
  "payload": {},
  "payload_hash": "sha256:..."
}
```

Event payloads are typed by `event_type` and `schema_version`. Unknown event types must be safely ignored or quarantined by consumers; they must not be guessed.

### 3.15 Artifact Reference

An **Artifact Reference** points to an immutable or versioned payload in a controlled artifact store.

Minimum fields: `artifact_id`, `storage_locator`, `media_type`, `byte_length`, `content_hash`, `created_by`, `created_at`, `access_policy_ref`, `version`, `retention_class`.

The artifact store must validate content hash on ingest and on retrieval where integrity assurance is required. A metadata string that merely looks like a SHA-256 digest is not proof of content integrity.

---

## 4. Shared Situation Board

### 4.1 Definition

The **Shared Situation Board** is a permission-filtered, revisioned read model of the federation's current operational state. It is derived from authoritative domain state and committed events. It is not independently writable.

### 4.2 Board sections

The default project board contains:

1. **Current objectives:** current objective revision, constraints, and acceptance contract references.
2. **Operational status:** project state, active blockers, unresolved conflicts, and system health indicators.
3. **Commitments:** owner, work item, status, lease validity, due information, and revision.
4. **Dependencies:** blockers, prerequisites, affected work, and stale dependency references.
5. **Evidence and decisions:** relevant supported claims, contested claims, decisions, and provenance links.
6. **Recent events:** ordered, filterable state changes with actor and revision.
7. **Agent presence:** membership, session state, declared availability, and capability declaration version.

### 4.3 Board consistency contract

Every board response must include `project_revision`, `generated_at`, and `projection_checkpoint`. Clients must be able to detect whether a board view is stale relative to an event cursor or requested minimum revision.

A board projection may be eventually consistent, but authoritative command handling must read the transactional source of truth. A client requiring read-after-write consistency may request `min_project_revision`; the service must wait within a bounded timeout or return an explicit not-yet-consistent response.

### 4.3.1 Projection recovery

A projection must be rebuildable from authoritative state and retained events. Projection checkpoints identify the last fully applied event cursor. If a projection fails or detects an invalid sequence, it must stop advertising itself as current, rebuild or resynchronize, and expose its lag/health state. A projection repair must never write back into authoritative domain state.

### 4.4 Information relevance and notification

All authorized events remain queryable according to policy. Notifications are selective. The dispatcher routes events based on:

- Explicit subscription filters.
- Ownership of affected commitments.
- Dependency graph impact.
- Membership and policy scope.
- Mandatory notification rules for security, authorization, objective revision, ownership transfer, and invalidation of an agent's active commitment.

Agents may choose additional interests, but cannot unsubscribe from mandatory events that directly affect their commitments, authorization, or safety obligations.

### 4.5 Acknowledgement semantics

Delivery, receipt, acknowledgement, and acceptance are distinct:

- `delivered`: transport reports successful delivery attempt.
- `received`: agent endpoint confirms message receipt.
- `acknowledged`: agent confirms it has registered the event for handling.
- `accepted`: agent explicitly accepts a proposed change or commitment.
- `contested`: agent records a reasoned objection.

Silence is not acceptance. Acknowledgement does not imply agreement.

---

## 5. Command, State Transition, and Concurrency Protocol

### 5.1 Command envelope

Every mutating request is a command, not a direct database write.

Minimum command fields: `command_id`, `command_type`, `schema_version`, `federation_id`, `project_id`, `actor`, `issued_at`, `expected_revision`, `idempotency_key`, `correlation_id`, `payload`.

### 5.2 Command processing sequence

1. Authenticate the principal and session.
2. Resolve membership and authorization scope.
3. Validate request schema and protocol version.
4. Check idempotency key and request hash.
5. Load authoritative aggregate/project state.
6. Enforce expected revision and lease/fencing rules.
7. Execute the single Domain Kernel transition.
8. Persist state and event/outbox record in one transaction.
9. Return the committed revision and event cursor.
10. Deliver events asynchronously from the durable outbox.

### 5.3 Optimistic concurrency

Every aggregate has a monotonically increasing `aggregate_revision`. Project-level changes also advance `project_revision` where they affect the shared situation. A command that modifies an aggregate must provide `expected_revision`.

If the expected revision does not match, the server returns `409 REVISION_CONFLICT` with the current revision and a safe reference to the current state. It must not silently merge semantically conflicting changes.

### 5.4 Idempotency

Mutating commands require an idempotency key scoped to `(principal, project, command_type)`. The service stores the request hash and result. Reusing a key with the same request returns the original result; reusing it with a different request returns `409 IDEMPOTENCY_KEY_REUSE`.

### 5.5 Leases and fencing tokens

A lease grants temporary execution ownership over a claimable work item or resource. Lease fields: `lease_id`, `subject_ref`, `holder_agent_id`, `expires_at`, `fencing_token`, `issued_at`, `renewed_at`.

The fencing token is monotonically increasing. Any write based on an older token is rejected even if the old agent believes its lease is still valid. Lease expiry alone does not prove an agent is dead; it only permits policy-controlled recovery or reassignment.

### 5.6 Atomic claim

Claiming a work item is an atomic server operation. For a single-owner work item, only one active commitment may exist at a time. The server must serialize competing claims or use a compare-and-swap transaction. The loser receives a conflict response with current ownership status, subject to access policy.

### 5.7 No hidden writes

UI, adapter, notification worker, or projection process must not bypass command handlers to mutate domain state. Administrative repair must use an audited maintenance command with explicit authority and event lineage.

---

## 6. Work and Commitment State Machines

### 6.1 Work item lifecycle

```mermaid
stateDiagram-v2
  [*] --> Proposed
  Proposed --> Ready: requirements accepted
  Proposed --> Cancelled: withdrawn
  Ready --> Claimed: atomic claim
  Claimed --> Active: owner starts
  Claimed --> Ready: claim released / lease expires
  Active --> Blocked: dependency or external blocker
  Blocked --> Active: blocker cleared
  Active --> Review: deliverable submitted
  Review --> Completed: acceptance passed
  Review --> Active: revision requested
  Ready --> Cancelled: authorized cancellation
  Claimed --> Cancelled: authorized cancellation
  Active --> Cancelled: authorized cancellation
  Blocked --> Cancelled: authorized cancellation
```

Terminal states are `Completed` and `Cancelled`. Reopening a completed item creates a new revision or successor work item; it must not erase completion history.

### 6.2 Commitment lifecycle

`Proposed -> Accepted -> Active -> Fulfilled` with alternative transitions to `Declined`, `Released`, `Expired`, `Breached`, or `Superseded`.

A commitment must identify its owner and scope. It cannot be silently transferred. Transfer requires an explicit release/reassignment event and a new acceptance by the receiving agent, unless an emergency governance policy authorizes temporary reassignment.

### 6.3 Dependency invalidation

When a source item changes revision or status, the system evaluates dependent edges. It may mark a dependency `stale`, `satisfied`, `blocked`, or `requires_reassessment`. It must not assume that every dependent deliverable is invalid; affected agents or authorized reviewers must reassess according to dependency semantics.

### 6.4 Completion semantics

`Completed` means the declared acceptance contract was evaluated and passed within its defined scope. It does not mean the work is universally correct or that all downstream objectives are complete. Acceptance criteria must be machine-readable or explicitly identified as requiring human review.

---

## 7. Evidence, Verification, and Epistemic Conflict

### 7.1 Evidence lifecycle

Initial statuses:

- `Proposed`: submitted but not yet assessed.
- `Supported`: sufficient supporting verification exists within a stated scope.
- `Contested`: credible contradictory evidence or unresolved challenge exists.
- `Refuted`: evidence has been adequately refuted within a stated scope.
- `Superseded`: a newer record replaces its current operational use while preserving history.

Status is scoped and revisable. `Supported` is not absolute truth. `Refuted` does not delete the record. A later verification may reopen or supersede a status through an append-only event.

### 7.2 Verification independence

A verification record must describe method, scope, sources used, and known source overlap. Independence is assessed by source and method diversity, not by counting agent endorsements. Multiple agents repeating one source count as correlated support.

### 7.3 Conflict handling protocol

1. Detect incompatible claims, requirements, dependencies, ownership, or authorization assertions.
2. Create a Conflict Record referencing the conflicting subjects.
3. Classify the conflict and determine affected scope.
4. Gather independent verification or clarification where possible.
5. Record each position and supporting evidence without destructive overwrite.
6. Apply the relevant resolution authority: factual/interpretive review, owner negotiation, policy rule, or human governance.
7. If unresolved, preserve the conflict as open and mark affected actions as blocked, conditional, or permitted under an explicit risk policy.
8. Record the resolution decision, authority basis, evidence, and supersession links.

### 7.4 No majority-as-truth rule

Voting may be used for a governance decision if policy explicitly permits it. It must not be treated as a method for establishing factual truth. A numerical majority of agents does not transform correlated or unsupported assertions into verified evidence.

### 7.5 Discovery priority

The first submitter receives provenance credit and the submission timestamp, not automatic authority over interpretation or action. A later independent verifier may have stronger grounds for a particular claim. The system must preserve both roles.

---

## 8. Authorization, Governance, and Security

### 8.1 Authentication

Production authentication must use verifiable credentials issued by a trusted identity provider or federation enrollment authority. Caller-controlled headers such as `X-Tenant-ID` or `X-Actor-ID` are prohibited as proof of identity. Such headers may be accepted only in isolated local-development mode and must be impossible to enable accidentally in production configuration.

### 8.2 Authorization model

Use scoped role-based permissions with attribute conditions. Initial roles may include:

- `federation_admin`: manages federation membership and policy.
- `project_governor`: manages project objectives, reserved approvals, and exceptional recovery.
- `agent_member`: reads authorized state and submits permitted commands.
- `reviewer`: performs designated verification or acceptance actions.
- `auditor`: reads audit records within scope without mutating state.

Roles are not mutually exclusive, and every permission is scoped to federation/project/resource/action. Capability claims do not grant authorization.

### 8.3 Human reserved powers

Policy may reserve actions such as membership revocation, policy changes, irreversible external actions, cross-federation data release, credential rotation, and exceptional ownership reassignment for human approval. FCF records approval and execution separately.

### 8.4 Least privilege and data visibility

Evidence metadata visibility and artifact payload access may differ. The system must support field-level or object-level policy where necessary. Agent membership does not imply access to all project artifacts or private notes.

### 8.5 Audit and tamper evidence

Security-sensitive actions, membership changes, role grants, policy updates, artifact access, conflict resolutions, and administrative repairs must be audited. Event storage should support tamper-evident chaining or equivalent integrity controls. Append-only does not mean immutable against infrastructure administrators by magic; operational controls, backups, key management, and external audit anchoring are required.

---

## 9. Event Delivery and Reliability

### 9.1 Transactional outbox

Every state-changing transaction writes its domain state and outbox event atomically. A separate dispatcher publishes outbox records. This prevents the failure mode where database state commits but the corresponding notification is lost.

### 9.2 Delivery guarantee

The initial guarantee is **at-least-once delivery**, not exactly-once execution. Consumers must be idempotent using `event_id` and aggregate revision. Duplicate events are expected and must be harmless.

### 9.3 Ordering

Global total ordering is not required. Events are ordered per aggregate and carry project revision where relevant. Consumers must detect gaps and request replay or state resynchronization. Cross-aggregate causality is represented by `correlation_id`, `causation_id`, and explicit dependency references.

### 9.4 Retry and dead-letter handling

Transient delivery failures are retried with bounded exponential backoff and jitter. Permanently failing events enter a dead-letter queue with diagnostics and operator visibility. Dead-letter records must be replayable after correction without altering original event identity.

### 9.5 Offline agents

An offline agent retains its last known cursor. On reconnect it requests events after that cursor or a fresh board snapshot if the cursor has expired. The service must return an explicit resynchronization requirement rather than silently presenting an incomplete event stream.

### 9.6 Notification does not own truth

A notification payload is a pointer and summary of an authoritative event. The agent must fetch the authorized current state before making a consequential command. Notifications may be delayed, duplicated, or reordered.

---

## 10. Protocol and API Surface

The protocol is transport-neutral. The first implementation may expose HTTPS/JSON APIs and server-sent events or WebSocket notifications. Transport choice must not alter domain semantics.

### 10.1 Required command families

| Family | Representative operations |
|---|---|
| Enrollment | register principal, establish session, join/leave federation |
| Capability | publish capability declaration, revoke/expire declaration |
| Project | create project, read board, revise objective, close project |
| Work | create work item, claim, start, block, submit, complete, cancel |
| Commitment | propose, accept, revise, release, transfer, renew lease |
| Dependency | create, update, invalidate, satisfy, remove with audit |
| Evidence | submit, supersede, attach artifact, challenge |
| Verification | verify, contest, refute, reopen assessment |
| Conflict | raise, classify, propose resolution, resolve, reopen |
| Decision | propose, approve, reject, supersede |
| Events | subscribe, acknowledge, replay, resynchronize |
| Governance | grant/revoke role, update policy, approve reserved action |

### 10.2 Required read surfaces

- Agent identity and membership view.
- Capability declaration view.
- Project board snapshot with revision.
- Work item and commitment detail.
- Dependency graph slice.
- Evidence and verification lineage.
- Conflict and decision history.
- Event cursor and replay endpoint.
- Audit history within authorization scope.

### 10.3 Error model

Errors must be machine-readable and stable. Initial codes:

`UNAUTHENTICATED`, `FORBIDDEN`, `NOT_FOUND`, `SCHEMA_INVALID`, `UNSUPPORTED_PROTOCOL_VERSION`, `REVISION_CONFLICT`, `IDEMPOTENCY_KEY_REUSE`, `LEASE_EXPIRED`, `FENCING_TOKEN_STALE`, `INVALID_STATE_TRANSITION`, `DEPENDENCY_BLOCKED`, `CONFLICT_OPEN`, `POLICY_APPROVAL_REQUIRED`, `RATE_LIMITED`, `RESYNC_REQUIRED`, `INTERNAL_ERROR`.

Each error includes `code`, `message`, `correlation_id`, and safe structured details. Sensitive details must not leak across authorization boundaries.

### 10.4 Protocol versioning

Every command, event, and capability declaration carries a schema version. Additive optional fields may be backward-compatible if consumers ignore unknown fields. Semantic changes require a new schema major version or an explicit compatibility adapter. No consumer may infer semantics from field names alone.

---

## 11. Storage and Persistence Baseline

The protocol is logically storage-independent. The initial reference implementation may use PostgreSQL for transactional state, outbox, membership, and event metadata, plus a separate artifact storage adapter for payload bytes.

Required properties:

- Transactional atomicity for state plus outbox.
- Unique constraints for idempotency keys and active single-owner claims.
- Optimistic revision checks.
- Explicit tenant/federation/project scoping in every repository query.
- Database-enforced isolation policies where supported, plus application authorization.
- Append-only event semantics at the application and database permission layers.
- Backup, restore, retention, and migration procedures.
- Artifact hash calculation and verification on actual bytes.

A PostgreSQL row-level security policy is defense in depth, not a replacement for authorization logic. All database access must use a trusted authenticated context; a caller must not be able to choose arbitrary tenant/actor identity through request fields.

---

## 12. Rust Implementation Structure

The first implementation should use a modular Rust workspace. Crate names are provisional; dependency direction is normative.

```text
fcf/
  Cargo.toml
  crates/
    fcf-domain/          # entities, value objects, invariants, state machines
    fcf-application/     # command handlers, use cases, transaction orchestration
    fcf-protocol/        # DTOs, schemas, event/command envelopes, versioning
    fcf-ports/           # repository, identity, artifact, event, clock interfaces
    fcf-adapters/        # PostgreSQL, identity provider, artifact store, transport adapters
    fcf-service/         # process composition, HTTP API, health, configuration
    fcf-worker/          # outbox dispatch, projections, subscriptions, retries
    fcf-conformance/     # protocol and state-machine conformance tests
  migrations/
  schemas/
  docs/
```

### 12.1 Dependency rules

- `fcf-domain` depends on no transport, database, vendor SDK, or application framework.
- `fcf-application` depends on `fcf-domain` and abstract ports.
- `fcf-protocol` defines wire contracts and must not own domain decisions.
- `fcf-adapters` implement ports and may depend on infrastructure libraries.
- `fcf-service` composes the application and adapters; it contains no duplicated business rules.
- `fcf-worker` invokes application use cases or projection interfaces; it must not bypass domain invariants.
- `fcf-conformance` validates externally observable protocol behavior.

### 12.2 Error and type discipline

Use typed domain errors and explicit conversion to protocol errors. Avoid stringly typed state names and arbitrary JSON blobs for core fields. Extension payloads may use versioned JSON, but core identifiers, status, revision, actor, scope, and timestamps must be typed.

### 12.3 Async boundary

Async I/O belongs in application/adapters. Pure domain transitions should remain deterministic and synchronous where practical. Clock, ID generation, and policy evaluation dependencies should be injected through ports where determinism is required for tests.

---

## 13. Observability and Operations

Required structured fields for logs and traces: `federation_id`, `project_id`, `agent_id`, `session_id`, `command_id`, `event_id`, `correlation_id`, `aggregate_id`, `aggregate_revision`, `protocol_version`.

Initial operational metrics:

- Command acceptance/rejection counts by error code.
- Revision conflicts and idempotency replays.
- Outbox backlog, delivery lag, retries, and dead-letter count.
- Projection lag and resynchronization frequency.
- Active/expired leases and stale fencing-token rejections.
- Open conflicts by type and age.
- Agent session health and event acknowledgement latency.

Metrics must not be used as an unqualified ranking of agent intelligence or worth. Performance observations are scoped operational data, not a universal trust score.

---

## 14. Threat and Failure Model

FCF v0.1 must explicitly handle:

1. Forged actor or tenant identity.
2. Unauthorized reads or writes across federation/project boundaries.
3. Malformed or oversized payloads and schema confusion.
4. Duplicate, delayed, reordered, or lost notifications.
5. Concurrent claims and stale writes.
6. Expired leases and delayed agents attempting writes.
7. Evidence tampering, false provenance, and caller-supplied fake hashes.
8. Correlated verification presented as independent support.
9. Malicious or compromised agent submissions.
10. Projection lag or corrupted read models.
11. Database outage between state and event publication.
12. Agent departure while holding active commitments.
13. Policy changes during in-flight work.
14. Protocol-version mismatch between agent and federation.

For every failure, the system must prefer explicit rejection, quarantine, or marked uncertainty over silent acceptance.

---

## 15. Protocol Conformance and Engineering Acceptance

These are infrastructure conformance tests, not domain research experiments. Tests use synthetic fixtures with deterministic expected outcomes.

### 15.1 Required acceptance tests

| ID | Scenario | Required result |
|---|---|---|
| FCF-C01 | Two agents read a board after a committed revision | Both can identify the same authoritative project revision |
| FCF-C02 | Agent submits command with stale aggregate revision | Server rejects with `REVISION_CONFLICT`; no mutation occurs |
| FCF-C03 | Two agents concurrently claim one single-owner item | Exactly one claim succeeds |
| FCF-C04 | Same idempotency key and same request repeated | Original result is returned; no duplicate transition |
| FCF-C05 | Same idempotency key with different request | Request is rejected |
| FCF-C06 | State commits while dispatcher is offline | Outbox retains event and dispatches after recovery |
| FCF-C07 | Consumer receives duplicate event | No duplicate side effect |
| FCF-C08 | Consumer detects event sequence gap | It requests replay or full resynchronization |
| FCF-C09 | Evidence is challenged by counter-evidence | Both records remain; conflict is represented |
| FCF-C10 | Two verifiers use the same underlying source | Source overlap is visible; no false independence assertion |
| FCF-C11 | Expired lease holder submits with stale fencing token | Write is rejected |
| FCF-C12 | Unauthorized agent requests artifact bytes | Access is denied even if metadata is visible |
| FCF-C13 | Objective revision affects dependent work | Impact is recorded and affected agents are notified |
| FCF-C14 | Agent reconnects after event retention window | Server requires explicit snapshot resynchronization |
| FCF-C15 | Administrative correction is performed | It is authorized, audited, and does not erase prior history |

### 15.2 Acceptance gate for P1

P0 is ready for implementation when:

- Core object definitions and lifecycle semantics are internally consistent.
- Command/event envelopes and revision semantics are defined.
- Authorization boundaries and reserved powers are explicit.
- Outbox, idempotency, lease, and concurrency rules are testable.
- Board projection is clearly separated from authoritative state.
- Rust crate boundaries preserve a single domain authority.
- All unresolved decisions are recorded rather than silently assumed.

P1 is not accepted merely because the service compiles. It must pass the conformance suite against a real transactional database and demonstrate recovery after process restart.

---

## 16. Decisions and Open Questions

The following decisions are fixed for v0.1:

| Decision | v0.1 position |
|---|---|
| System model | Federation of independently operated agents |
| Core implementation language | Rust |
| Shared board | Derived read model, not source of truth |
| Domain authority | One Domain Kernel |
| Event publication | Transactional outbox, at-least-once delivery |
| Concurrency | Aggregate revisions, idempotency, leases, fencing tokens |
| Evidence history | Append-only lineage; corrections supersede, not overwrite |
| Disagreement | First-class conflict state; no majority-as-truth rule |
| Authentication | Trusted credentials; caller-controlled identity headers forbidden in production |
| Business-domain logic | Explicitly excluded from core framework |

The following remain open and must be decided before production hardening:

1. **Identity federation:** which credential format and issuer model to support first (for example, OIDC-backed workload identity, mTLS identities, or both).
2. **External agent protocol adapters:** which versions of MCP, A2A, or other protocols are worth implementing after reviewing their current specifications and interoperability requirements.
3. **Event transport:** database polling, broker-backed dispatch, or a hybrid. The transactional outbox remains mandatory regardless of transport.
4. **Artifact storage:** local filesystem/object storage interface and encryption/key-management strategy.
5. **Policy language:** typed internal policy model first, with possible external policy engine later.
6. **Human approval UX:** API-level approval protocol first; user interface can follow.
7. **Multi-region operation:** explicitly out of scope for the first prototype; do not imply global consistency.
8. **Retention and privacy policy:** configurable by federation and artifact class, subject to applicable law and operator policy.

These open items do not block a local single-region protocol prototype, provided their interfaces are not hard-coded in ways that prevent later substitution.

---

## 17. P1 Implementation Sequence

1. Create Rust workspace and enforce crate dependency rules.
2. Implement typed domain entities and state machines without database dependencies.
3. Implement deterministic domain conformance tests.
4. Define JSON Schemas and protocol version registry for commands/events.
5. Implement application command handlers and repository/transaction ports.
6. Implement PostgreSQL persistence, revision checks, idempotency, and transactional outbox.
7. Implement identity and authorization adapter for development, with a production-safe configuration boundary.
8. Implement event dispatcher, replay cursor, and board projections.
9. Implement a minimal agent client/simulator using the public protocol only.
10. Run conformance tests, restart/recovery tests, and security boundary tests.

No full dashboard, autonomous organization planner, external vendor integrations, or domain-specific workflow engine is required for P1.

---

## 18. Final Architecture Contract

FCF is not a central brain directing subordinate agents. It is a governed coordination environment in which autonomous agents can maintain independent cognition while sharing the minimum authoritative state necessary for coherent collective action.

The federation guarantees:

- Who is participating and what they are authorized to do.
- Which shared state revision is authoritative.
- Which commitments and dependencies currently exist.
- Which evidence and decisions support operational claims.
- Which changes occurred, who caused them, and who must be informed.
- How conflicts, stale information, concurrent writes, and failures are represented and recovered.

The federation does **not** guarantee that every agent is correct, that all disagreements can be resolved, or that a shared decision is objectively true. It guarantees that the process by which the organization forms and changes its operational state is explicit, traceable, permissioned, and testable.

**End of FCF Protocol & Architecture Specification v0.1.**
