# FCF v0.1 verification checklist

## Automated
Run `cargo test --workspace`. Expected: all tests pass.

Run `cargo run -p fcf-demo`. Expected: the board shows three agents, one claimed work item, one contested evidence record, and eight ordered events.

## Manual acceptance
1. Change the second registration's expected project revision from `1` to `0`; expect `ProjectRevisionConflict`.
2. Change the second claim to use the same project revision after the first claim; expect stale project revision rejection. If updated to the current project revision, expect `WorkItemNotClaimable`.
3. Attempt evidence assessment by its author; expect `EvidenceSelfVerification`.
4. Submit the same evidence ID twice; expect `EvidenceAlreadyExists`.
5. Attempt a write using an unregistered Agent ID; expect `AgentNotRegistered`.
6. Confirm a contested evidence record remains on the board and the event log retains both assessment events.

## What passing means
Passing verifies deterministic in-process collaboration rules only. It does not establish distributed correctness, security, persistence durability, or cross-vendor interoperability. Those require later integration tests against the actual database, transport and identity adapters.
