# Federated Collaboration Framework (FCF) v0.1

A domain-neutral Rust prototype for coordinating autonomous agents through shared state, evidence records, commitments and append-only events.

## Requirements
- Rust 1.85 or newer (edition 2024)
- Cargo

## Run
Windows PowerShell:
```powershell
.\scripts\verify.ps1
```

Linux/macOS:
```bash
./scripts/verify.sh
```

Or run individual commands:
```bash
cargo test --workspace
cargo run -p fcf-demo
cargo fmt --all -- --check
cargo clippy --workspace --all-targets -- -D warnings
```

No third-party crates are required. The prototype is intentionally in-memory so that the collaboration invariants can be verified before introducing database or network complexity.

## What the demo exercises
1. Three independent agent identities join one project.
2. An agent publishes a work item to the shared situation board.
3. A different agent claims it; a competing claim is rejected.
4. An agent submits evidence. A different agent supports it.
5. A third agent contests the evidence; the dispute remains visible.
6. The board is projected from current state and the event history.

## Important limits
This is a local, single-process verification prototype. It does **not** yet provide network transport, durable persistence, authentication, multi-tenant isolation, distributed leases, transactional outbox, schema registry, or production security. The in-memory methods are atomic only within one process. Do not expose this demo to an untrusted network or use it as a production service.

## Protocol specification
See `docs/FCF_Protocol_v0.1.md` for the architecture and protocol baseline.

## Architecture
- `fcf-domain`: transport/persistence-independent domain invariants and state machines.
- `fcf-protocol`: transport-neutral command/event envelopes.
- `fcf-application`: use cases and in-memory repository adapter.
- `fcf-demo`: executable end-to-end scenario.

The domain crate is the sole owner of domain transitions. The application layer orchestrates use cases; it must not duplicate domain rules.
