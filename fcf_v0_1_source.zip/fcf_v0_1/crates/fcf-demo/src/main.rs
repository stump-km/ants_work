use fcf_application::Workspace;
use fcf_domain::{AgentId, EvidenceId, EvidenceStatus, ProjectId, Revision, WorkItemId};

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut workspace = Workspace::new(ProjectId::from("fcf-demo"));
    println!("FCF v0.1 — federated collaboration protocol demo\n");

    workspace.register_agent(AgentId::from("alpha"), Revision::new(0))?;
    workspace.register_agent(AgentId::from("beta"), Revision::new(1))?;
    workspace.register_agent(AgentId::from("gamma"), Revision::new(2))?;
    println!("[1] Three independent agents registered.");

    workspace.create_work_item(&AgentId::from("alpha"), WorkItemId::from("work-001"), Revision::new(3))?;
    println!("[2] Alpha published work-001 to the shared board.");

    workspace.claim_work_item(&AgentId::from("beta"), &WorkItemId::from("work-001"), Revision::new(4), Revision::new(1))?;
    println!("[3] Beta claimed work-001. A second claim would be rejected.");

    workspace.submit_evidence(&AgentId::from("alpha"), EvidenceId::from("evidence-001"), "A new fact affects the current plan", Revision::new(5))?;
    println!("[4] Alpha submitted evidence-001.");
    workspace.assess_evidence(&AgentId::from("beta"), &EvidenceId::from("evidence-001"), EvidenceStatus::Supported, Revision::new(6), Revision::new(0))?;
    println!("[5] Beta independently supported the evidence.");
    workspace.assess_evidence(&AgentId::from("gamma"), &EvidenceId::from("evidence-001"), EvidenceStatus::Contested, Revision::new(7), Revision::new(1))?;
    println!("[6] Gamma contested it. The disagreement remains visible.");

    let board = workspace.board();
    println!("\n=== SHARED SITUATION BOARD ===");
    println!("Project: {} | revision: {}", board.project_id, board.project_revision);
    println!("Agents: {}", board.agents.iter().map(ToString::to_string).collect::<Vec<_>>().join(", "));
    for work in &board.work_items {
        println!("Work {}: {:?} | owner: {} | revision: {}", work.item.id, work.item.status,
            work.owner.as_ref().map(ToString::to_string).unwrap_or_else(|| "unassigned".into()), work.item.revision.value());
    }
    for evidence in &board.evidence {
        println!("Evidence {}: {:?} | author: {} | claim: {}", evidence.id, evidence.status, evidence.author, evidence.claim);
    }
    println!("\nEvent log:");
    for event in &board.recent_events {
        println!("#{:02} project-r{} {:?} by {} — {}", event.sequence, event.project_revision, event.kind, event.actor, event.detail);
    }
    println!("\nDemo completed. This is an in-memory protocol prototype, not a production server.");
    Ok(())
}
