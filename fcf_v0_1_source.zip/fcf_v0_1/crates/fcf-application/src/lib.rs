//! Application layer for the FCF in-memory verification prototype.
//! The in-memory repository is deliberately a test/demo adapter, not production persistence.

use std::collections::{HashMap, HashSet};
use fcf_domain::{
    AgentId, DomainError, EvidenceId, EvidenceRecord, EvidenceStatus, ProjectId,
    Revision, WorkItem, WorkItemId, WorkItemStatus,
};

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum ApplicationError {
    Domain(DomainError),
    AgentAlreadyRegistered,
    AgentNotRegistered,
    WorkItemAlreadyExists,
    WorkItemNotFound,
    EvidenceAlreadyExists,
    EvidenceNotFound,
    WorkItemNotClaimable,
    EvidenceSelfVerification,
    ProjectRevisionConflict { expected: u64, actual: u64 },
}

impl From<DomainError> for ApplicationError {
    fn from(value: DomainError) -> Self { Self::Domain(value) }
}

impl std::fmt::Display for ApplicationError {
    fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(formatter, "{self:?}")
    }
}

impl std::error::Error for ApplicationError {}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum EventKind {
    AgentRegistered,
    WorkItemCreated,
    WorkItemClaimed,
    EvidenceSubmitted,
    EvidenceAssessed,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EventRecord {
    pub sequence: u64,
    pub kind: EventKind,
    pub actor: AgentId,
    pub aggregate_id: String,
    pub project_revision: u64,
    pub detail: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WorkRecord {
    pub item: WorkItem,
    pub owner: Option<AgentId>,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct BoardSnapshot {
    pub project_id: ProjectId,
    pub project_revision: u64,
    pub agents: Vec<AgentId>,
    pub work_items: Vec<WorkRecord>,
    pub evidence: Vec<EvidenceRecord>,
    pub recent_events: Vec<EventRecord>,
}

/// Single-process application service. Methods are atomic within one mutable borrow.
/// A production adapter must execute state changes and outbox insertion in one DB transaction.
pub struct Workspace {
    project_id: ProjectId,
    project_revision: Revision,
    agents: HashSet<AgentId>,
    work_items: HashMap<WorkItemId, WorkRecord>,
    evidence: HashMap<EvidenceId, EvidenceRecord>,
    events: Vec<EventRecord>,
}

impl Workspace {
    #[must_use]
    pub fn new(project_id: ProjectId) -> Self {
        Self {
            project_id,
            project_revision: Revision::INITIAL,
            agents: HashSet::new(),
            work_items: HashMap::new(),
            evidence: HashMap::new(),
            events: Vec::new(),
        }
    }

    #[must_use]
    pub fn project_revision(&self) -> Revision { self.project_revision }

    fn check_project_revision(&self, expected: Revision) -> Result<(), ApplicationError> {
        if expected != self.project_revision {
            return Err(ApplicationError::ProjectRevisionConflict {
                expected: expected.value(), actual: self.project_revision.value(),
            });
        }
        Ok(())
    }

    fn ensure_agent(&self, agent: &AgentId) -> Result<(), ApplicationError> {
        if self.agents.contains(agent) { Ok(()) } else { Err(ApplicationError::AgentNotRegistered) }
    }

    fn append_event(&mut self, kind: EventKind, actor: AgentId, aggregate_id: String, detail: String) -> Result<(), ApplicationError> {
        self.project_revision = self.project_revision.next()?;
        let sequence = self.events.len() as u64 + 1;
        self.events.push(EventRecord {
            sequence, kind, actor, aggregate_id,
            project_revision: self.project_revision.value(), detail,
        });
        Ok(())
    }

    pub fn register_agent(&mut self, agent: AgentId, expected_project_revision: Revision) -> Result<Revision, ApplicationError> {
        self.check_project_revision(expected_project_revision)?;
        if self.agents.contains(&agent) { return Err(ApplicationError::AgentAlreadyRegistered); }
        self.agents.insert(agent.clone());
        self.append_event(EventKind::AgentRegistered, agent.clone(), agent.to_string(), "agent registered".into())?;
        Ok(self.project_revision)
    }

    pub fn create_work_item(&mut self, actor: &AgentId, id: WorkItemId, expected_project_revision: Revision) -> Result<Revision, ApplicationError> {
        self.check_project_revision(expected_project_revision)?;
        self.ensure_agent(actor)?;
        if self.work_items.contains_key(&id) { return Err(ApplicationError::WorkItemAlreadyExists); }
        let mut item = WorkItem::new(id.clone(), self.project_id.clone());
        item.transition(Revision::new(0), WorkItemStatus::Ready)?;
        self.work_items.insert(id.clone(), WorkRecord { item, owner: None });
        self.append_event(EventKind::WorkItemCreated, actor.clone(), id.to_string(), "work item ready for claim".into())?;
        Ok(self.project_revision)
    }

    pub fn claim_work_item(&mut self, actor: &AgentId, id: &WorkItemId, expected_project_revision: Revision, expected_work_revision: Revision) -> Result<Revision, ApplicationError> {
        self.check_project_revision(expected_project_revision)?;
        self.ensure_agent(actor)?;
        let record = self.work_items.get_mut(id).ok_or(ApplicationError::WorkItemNotFound)?;
        if record.owner.is_some() || record.item.status != WorkItemStatus::Ready {
            return Err(ApplicationError::WorkItemNotClaimable);
        }
        record.item.transition(expected_work_revision, WorkItemStatus::Claimed)?;
        record.owner = Some(actor.clone());
        self.append_event(EventKind::WorkItemClaimed, actor.clone(), id.to_string(), "work item claimed".into())?;
        Ok(self.project_revision)
    }

    pub fn submit_evidence(&mut self, actor: &AgentId, id: EvidenceId, claim: impl Into<String>, expected_project_revision: Revision) -> Result<Revision, ApplicationError> {
        self.check_project_revision(expected_project_revision)?;
        self.ensure_agent(actor)?;
        if self.evidence.contains_key(&id) { return Err(ApplicationError::EvidenceAlreadyExists); }
        let record = EvidenceRecord::proposed(id.clone(), actor.clone(), claim);
        self.evidence.insert(id.clone(), record);
        self.append_event(EventKind::EvidenceSubmitted, actor.clone(), id.to_string(), "evidence proposed".into())?;
        Ok(self.project_revision)
    }

    pub fn assess_evidence(&mut self, verifier: &AgentId, id: &EvidenceId, target: EvidenceStatus, expected_project_revision: Revision, expected_evidence_revision: Revision) -> Result<Revision, ApplicationError> {
        self.check_project_revision(expected_project_revision)?;
        self.ensure_agent(verifier)?;
        let record = self.evidence.get_mut(id).ok_or(ApplicationError::EvidenceNotFound)?;
        if &record.author == verifier { return Err(ApplicationError::EvidenceSelfVerification); }
        record.assess(expected_evidence_revision, target)?;
        self.append_event(EventKind::EvidenceAssessed, verifier.clone(), id.to_string(), format!("evidence assessed: {target:?}"))?;
        Ok(self.project_revision)
    }

    #[must_use]
    pub fn board(&self) -> BoardSnapshot {
        let mut agents: Vec<_> = self.agents.iter().cloned().collect();
        agents.sort_by(|a, b| a.as_str().cmp(b.as_str()));
        let mut work_items: Vec<_> = self.work_items.values().cloned().collect();
        work_items.sort_by(|a, b| a.item.id.as_str().cmp(b.item.id.as_str()));
        let mut evidence: Vec<_> = self.evidence.values().cloned().collect();
        evidence.sort_by(|a, b| a.id.as_str().cmp(b.id.as_str()));
        BoardSnapshot {
            project_id: self.project_id.clone(), project_revision: self.project_revision.value(),
            agents, work_items, evidence, recent_events: self.events.clone(),
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn setup() -> Workspace {
        let mut ws = Workspace::new(ProjectId::from("demo-project"));
        ws.register_agent(AgentId::from("alpha"), Revision::new(0)).unwrap();
        ws.register_agent(AgentId::from("beta"), Revision::new(1)).unwrap();
        ws.register_agent(AgentId::from("gamma"), Revision::new(2)).unwrap();
        ws
    }

    #[test]
    fn board_exposes_common_state_and_event_sequence() {
        let mut ws = setup();
        ws.create_work_item(&AgentId::from("alpha"), WorkItemId::from("w1"), Revision::new(3)).unwrap();
        let board = ws.board();
        assert_eq!(board.agents.len(), 3);
        assert_eq!(board.work_items.len(), 1);
        assert_eq!(board.recent_events.last().unwrap().sequence, 4);
        assert_eq!(board.project_revision, 4);
    }

    #[test]
    fn stale_project_revision_is_rejected() {
        let mut ws = setup();
        let result = ws.create_work_item(&AgentId::from("alpha"), WorkItemId::from("w1"), Revision::new(0));
        assert_eq!(result, Err(ApplicationError::ProjectRevisionConflict { expected: 0, actual: 3 }));
        assert!(ws.board().work_items.is_empty());
    }

    #[test]
    fn only_one_agent_can_claim_a_work_item() {
        let mut ws = setup();
        ws.create_work_item(&AgentId::from("alpha"), WorkItemId::from("w1"), Revision::new(3)).unwrap();
        ws.claim_work_item(&AgentId::from("beta"), &WorkItemId::from("w1"), Revision::new(4), Revision::new(1)).unwrap();
        let result = ws.claim_work_item(&AgentId::from("gamma"), &WorkItemId::from("w1"), Revision::new(5), Revision::new(2));
        assert_eq!(result, Err(ApplicationError::WorkItemNotClaimable));
        assert_eq!(ws.board().work_items[0].owner, Some(AgentId::from("beta")));
    }

    #[test]
    fn evidence_requires_independent_verifier_and_can_be_contested() {
        let mut ws = setup();
        ws.submit_evidence(&AgentId::from("alpha"), EvidenceId::from("e1"), "claim X", Revision::new(3)).unwrap();
        let self_check = ws.assess_evidence(&AgentId::from("alpha"), &EvidenceId::from("e1"), EvidenceStatus::Supported, Revision::new(4), Revision::new(0));
        assert_eq!(self_check, Err(ApplicationError::EvidenceSelfVerification));
        ws.assess_evidence(&AgentId::from("beta"), &EvidenceId::from("e1"), EvidenceStatus::Supported, Revision::new(4), Revision::new(0)).unwrap();
        ws.assess_evidence(&AgentId::from("gamma"), &EvidenceId::from("e1"), EvidenceStatus::Contested, Revision::new(5), Revision::new(1)).unwrap();
        let board = ws.board();
        assert_eq!(board.evidence[0].status, EvidenceStatus::Contested);
        assert_eq!(board.evidence[0].revision, Revision::new(2));
    }

    #[test]
    fn unregistered_agent_cannot_write() {
        let mut ws = setup();
        let result = ws.create_work_item(&AgentId::from("outsider"), WorkItemId::from("w1"), Revision::new(3));
        assert_eq!(result, Err(ApplicationError::AgentNotRegistered));
    }
}
