//! FCF's transport- and persistence-independent domain kernel.
//!
//! This crate owns collaboration invariants and deterministic state transitions.
//! It intentionally has no async runtime, database, HTTP, vendor SDK, or agent SDK.

use std::fmt;

macro_rules! string_id {
    ($name:ident) => {
        #[derive(Clone, Debug, Eq, Hash, Ord, PartialEq, PartialOrd)]
        pub struct $name(String);

        impl $name {
            #[must_use]
            pub fn new(value: impl Into<String>) -> Self {
                Self(value.into())
            }

            #[must_use]
            pub fn as_str(&self) -> &str {
                &self.0
            }
        }

        impl From<&str> for $name {
            fn from(value: &str) -> Self {
                Self::new(value)
            }
        }

        impl From<String> for $name {
            fn from(value: String) -> Self {
                Self::new(value)
            }
        }

        impl fmt::Display for $name {
            fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
                formatter.write_str(&self.0)
            }
        }
    };
}

string_id!(FederationId);
string_id!(ProjectId);
string_id!(AgentId);
string_id!(WorkItemId);
string_id!(CommitmentId);
string_id!(EvidenceId);
string_id!(EventId);
string_id!(CommandId);
string_id!(CorrelationId);

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub struct Revision(u64);

impl Revision {
    pub const INITIAL: Self = Self(0);

    #[must_use]
    pub const fn new(value: u64) -> Self {
        Self(value)
    }

    #[must_use]
    pub const fn value(self) -> u64 {
        self.0
    }

    pub fn next(self) -> Result<Self, DomainError> {
        self.0
            .checked_add(1)
            .map(Self)
            .ok_or(DomainError::RevisionExhausted)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub enum DomainError {
    InvalidTransition { from: String, to: String },
    RevisionConflict { expected: u64, actual: u64 },
    RevisionExhausted,
    OwnershipMismatch,
}

impl fmt::Display for DomainError {
    fn fmt(&self, formatter: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            Self::InvalidTransition { from, to } => {
                write!(formatter, "invalid transition from {from} to {to}")
            }
            Self::RevisionConflict { expected, actual } => {
                write!(formatter, "revision conflict: expected {expected}, actual {actual}")
            }
            Self::RevisionExhausted => formatter.write_str("revision counter exhausted"),
            Self::OwnershipMismatch => formatter.write_str("actor is not the current owner"),
        }
    }
}

impl std::error::Error for DomainError {}

/// A value whose changes must be based on the revision the caller observed.
#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Revisioned<T> {
    value: T,
    revision: Revision,
}

impl<T> Revisioned<T> {
    #[must_use]
    pub const fn new(value: T) -> Self {
        Self {
            value,
            revision: Revision::INITIAL,
        }
    }

    #[must_use]
    pub const fn revision(&self) -> Revision {
        self.revision
    }

    #[must_use]
    pub const fn value(&self) -> &T {
        &self.value
    }

    pub fn update(
        &mut self,
        expected: Revision,
        update: impl FnOnce(&mut T),
    ) -> Result<Revision, DomainError> {
        if expected != self.revision {
            return Err(DomainError::RevisionConflict {
                expected: expected.value(),
                actual: self.revision.value(),
            });
        }

        let next = self.revision.next()?;
        update(&mut self.value);
        self.revision = next;
        Ok(next)
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum WorkItemStatus {
    Proposed,
    Ready,
    Claimed,
    Active,
    Blocked,
    Review,
    Completed,
    Cancelled,
}

impl WorkItemStatus {
    pub fn transition(self, target: Self) -> Result<Self, DomainError> {
        use WorkItemStatus::{
            Active, Blocked, Cancelled, Claimed, Completed, Proposed, Ready, Review,
        };

        let allowed = matches!(
            (self, target),
            (Proposed, Ready | Cancelled)
                | (Ready, Claimed | Cancelled)
                | (Claimed, Active | Ready | Cancelled)
                | (Active, Blocked | Review | Cancelled)
                | (Blocked, Active | Cancelled)
                | (Review, Completed | Active)
        );

        if allowed {
            Ok(target)
        } else {
            Err(DomainError::InvalidTransition {
                from: format!("{self:?}"),
                to: format!("{target:?}"),
            })
        }
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct WorkItem {
    pub id: WorkItemId,
    pub project_id: ProjectId,
    pub status: WorkItemStatus,
    pub revision: Revision,
}

impl WorkItem {
    #[must_use]
    pub fn new(id: WorkItemId, project_id: ProjectId) -> Self {
        Self {
            id,
            project_id,
            status: WorkItemStatus::Proposed,
            revision: Revision::INITIAL,
        }
    }

    pub fn transition(
        &mut self,
        expected_revision: Revision,
        target: WorkItemStatus,
    ) -> Result<Revision, DomainError> {
        if expected_revision != self.revision {
            return Err(DomainError::RevisionConflict {
                expected: expected_revision.value(),
                actual: self.revision.value(),
            });
        }

        let next_status = self.status.transition(target)?;
        let next_revision = self.revision.next()?;
        self.status = next_status;
        self.revision = next_revision;
        Ok(next_revision)
    }
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct Commitment {
    pub id: CommitmentId,
    pub work_item_id: WorkItemId,
    pub owner: AgentId,
    pub status: CommitmentStatus,
    pub revision: Revision,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum CommitmentStatus {
    Proposed,
    Accepted,
    Active,
    Fulfilled,
    Declined,
    Released,
    Expired,
    Breached,
    Superseded,
}

impl Commitment {
    #[must_use]
    pub fn proposed(
        id: CommitmentId,
        work_item_id: WorkItemId,
        owner: AgentId,
    ) -> Self {
        Self {
            id,
            work_item_id,
            owner,
            status: CommitmentStatus::Proposed,
            revision: Revision::INITIAL,
        }
    }

    pub fn accept(
        &mut self,
        actor: &AgentId,
        expected_revision: Revision,
    ) -> Result<Revision, DomainError> {
        if actor != &self.owner {
            return Err(DomainError::OwnershipMismatch);
        }
        if expected_revision != self.revision {
            return Err(DomainError::RevisionConflict {
                expected: expected_revision.value(),
                actual: self.revision.value(),
            });
        }
        if self.status != CommitmentStatus::Proposed {
            return Err(DomainError::InvalidTransition {
                from: format!("{:?}", self.status),
                to: "Accepted".to_owned(),
            });
        }
        self.status = CommitmentStatus::Accepted;
        self.revision = self.revision.next()?;
        Ok(self.revision)
    }
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum EvidenceStatus {
    Proposed,
    Supported,
    Contested,
    Refuted,
    Superseded,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EvidenceRecord {
    pub id: EvidenceId,
    pub author: AgentId,
    pub claim: String,
    pub status: EvidenceStatus,
    pub revision: Revision,
}

impl EvidenceRecord {
    #[must_use]
    pub fn proposed(id: EvidenceId, author: AgentId, claim: impl Into<String>) -> Self {
        Self {
            id,
            author,
            claim: claim.into(),
            status: EvidenceStatus::Proposed,
            revision: Revision::INITIAL,
        }
    }

    /// Changes the current assessment without deleting the historical record.
    /// Persistence adapters must append the corresponding assessment event.
    pub fn assess(
        &mut self,
        expected_revision: Revision,
        target: EvidenceStatus,
    ) -> Result<Revision, DomainError> {
        use EvidenceStatus::{Contested, Proposed, Refuted, Supported, Superseded};
        let allowed = matches!(
            (self.status, target),
            (Proposed, Supported | Contested | Refuted | Superseded)
                | (Supported, Contested | Refuted | Superseded)
                | (Contested, Supported | Refuted | Superseded)
                | (Refuted, Contested | Superseded)
        );

        if expected_revision != self.revision {
            return Err(DomainError::RevisionConflict {
                expected: expected_revision.value(),
                actual: self.revision.value(),
            });
        }
        if !allowed {
            return Err(DomainError::InvalidTransition {
                from: format!("{:?}", self.status),
                to: format!("{target:?}"),
            });
        }

        self.status = target;
        self.revision = self.revision.next()?;
        Ok(self.revision)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn work_item_follows_allowed_lifecycle() {
        let mut item = WorkItem::new("work-1".into(), "project-1".into());
        assert_eq!(item.transition(Revision::new(0), WorkItemStatus::Ready), Ok(Revision::new(1)));
        assert_eq!(item.transition(Revision::new(1), WorkItemStatus::Claimed), Ok(Revision::new(2)));
        assert_eq!(item.transition(Revision::new(2), WorkItemStatus::Active), Ok(Revision::new(3)));
        assert_eq!(item.status, WorkItemStatus::Active);
    }

    #[test]
    fn work_item_rejects_invalid_transition_without_mutation() {
        let mut item = WorkItem::new("work-1".into(), "project-1".into());
        let result = item.transition(Revision::new(0), WorkItemStatus::Completed);
        assert!(matches!(result, Err(DomainError::InvalidTransition { .. })));
        assert_eq!(item.status, WorkItemStatus::Proposed);
        assert_eq!(item.revision, Revision::new(0));
    }

    #[test]
    fn stale_revision_is_rejected_without_mutation() {
        let mut item = WorkItem::new("work-1".into(), "project-1".into());
        item.transition(Revision::new(0), WorkItemStatus::Ready).unwrap();
        let result = item.transition(Revision::new(0), WorkItemStatus::Claimed);
        assert_eq!(result, Err(DomainError::RevisionConflict { expected: 0, actual: 1 }));
        assert_eq!(item.status, WorkItemStatus::Ready);
    }

    #[test]
    fn only_owner_can_accept_commitment() {
        let owner = AgentId::from("agent-a");
        let mut commitment = Commitment::proposed(
            "commitment-1".into(),
            "work-1".into(),
            owner.clone(),
        );
        assert_eq!(
            commitment.accept(&AgentId::from("agent-b"), Revision::new(0)),
            Err(DomainError::OwnershipMismatch)
        );
        assert_eq!(commitment.accept(&owner, Revision::new(0)), Ok(Revision::new(1)));
    }

    #[test]
    fn evidence_can_be_contested_without_being_deleted() {
        let mut evidence = EvidenceRecord::proposed(
            "evidence-1".into(),
            "agent-a".into(),
            "A submitted claim",
        );
        evidence.assess(Revision::new(0), EvidenceStatus::Supported).unwrap();
        evidence.assess(Revision::new(1), EvidenceStatus::Contested).unwrap();
        assert_eq!(evidence.id.as_str(), "evidence-1");
        assert_eq!(evidence.status, EvidenceStatus::Contested);
        assert_eq!(evidence.revision, Revision::new(2));
    }
}
