//! Transport-neutral wire envelopes for FCF v0.1.
//!
//! Serialization adapters are intentionally deferred until the schema contract
//! is reviewed. These types contain no domain transition logic.

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct CommandEnvelope {
    pub command_id: String,
    pub command_type: String,
    pub schema_version: String,
    pub federation_id: String,
    pub project_id: String,
    pub actor_id: String,
    pub issued_at: String,
    pub expected_revision: u64,
    pub idempotency_key: String,
    pub correlation_id: String,
    pub payload_json: String,
}

#[derive(Clone, Debug, Eq, PartialEq)]
pub struct EventEnvelope {
    pub event_id: String,
    pub event_type: String,
    pub schema_version: String,
    pub federation_id: String,
    pub project_id: String,
    pub aggregate_type: String,
    pub aggregate_id: String,
    pub aggregate_revision: u64,
    pub project_revision: u64,
    pub actor_id: String,
    pub occurred_at: String,
    pub recorded_at: String,
    pub correlation_id: String,
    pub causation_id: String,
    pub payload_json: String,
    pub payload_hash: String,
}

#[derive(Clone, Copy, Debug, Eq, PartialEq)]
pub enum ProtocolMajorVersion {
    V1,
}

impl ProtocolMajorVersion {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::V1 => "1",
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn protocol_major_version_is_explicit() {
        assert_eq!(ProtocolMajorVersion::V1.as_str(), "1");
    }
}
