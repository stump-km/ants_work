$ErrorActionPreference = "Stop"
Set-Location (Join-Path $PSScriptRoot "..")

Write-Host "== FCF v0.1: formatting ==" -ForegroundColor Cyan
cargo fmt --all -- --check
if ($LASTEXITCODE -ne 0) { throw "cargo fmt failed" }

Write-Host "== FCF v0.1: tests ==" -ForegroundColor Cyan
cargo test --workspace
if ($LASTEXITCODE -ne 0) { throw "cargo test failed" }

Write-Host "== FCF v0.1: clippy ==" -ForegroundColor Cyan
cargo clippy --workspace --all-targets -- -D warnings
if ($LASTEXITCODE -ne 0) { throw "cargo clippy failed" }

Write-Host "== FCF v0.1: demo ==" -ForegroundColor Cyan
cargo run -p fcf-demo
if ($LASTEXITCODE -ne 0) { throw "demo failed" }

Write-Host "FCF verification commands completed successfully." -ForegroundColor Green
